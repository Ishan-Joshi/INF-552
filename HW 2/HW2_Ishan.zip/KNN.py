import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
#np.random.seed(0)
centroids = np.random.randn(3, 2)

cols = ["x", "y"]
Input_File = pd.read_csv("clusters.txt", sep = ',', skipinitialspace=True)
Input_File.columns = cols
Input_File["label"] = 0
x_vals = Input_File["x"]
y_vals = Input_File["y"]
vc_data = []
for i in range(len(Input_File)):
    vc_data.append(np.array([Input_File.iloc[i, 0] , Input_File.iloc[i, 1]]))
plt.scatter(x_vals, y_vals)


#   Calculating Distance from Centroids

def Calc_Distance(centroids, coordinates):
    distance = np.linalg.norm(coordinates - centroids)

    return distance


#   Compute and assign centroids
def kmeans():
    dist_arr = np.empty(shape=(len(vc_data),3))
    closest_cluster_index = []
    iterations = 0
    flag = False
    while(flag == False):
    #for lgt in range(0, 7):
        iterations += 1
        print("Iterations {0} has centroids: {1}".format(iterations, centroids))
        for i in range (len(vc_data)):
            for j in range(len(centroids)):
                distance_from_centroid = Calc_Distance(centroids=centroids[j], coordinates=vc_data[i])
                dist_arr[i,j] = distance_from_centroid
            closest_cluster = np.argmin(dist_arr[i])

            closest_cluster_index.append(closest_cluster)

            Input_File.loc[i, "label"] = closest_cluster

            #Plotting the Clusters
        colors = ['firebrick', 'gold', 'navy', 'lightseagreen', 'deepskyblue', 'mediumpurple',
                              'darkmagenta', 'palevioletred', 'darkgreen',  'darkorange', 'darkslategray', 'dimgrey']

        for i in range(len(centroids)):
            clt_color = colors[i]
            plt.scatter(centroids[i,0], centroids[i,1], s = 1000, marker="+")
            for i in range(len(centroids)):
                clt_data = Input_File[Input_File["label"] == i]
                cluster_x_vals = [clt_data["x"]]
                cluster_y_vals = [clt_data["y"]]
                plt.scatter(cluster_x_vals, cluster_y_vals, marker="o")
                i += 1

            plt.savefig("k-means{0}.png".format(iterations))
        plt.close()


            # Calculating new centroid
        repeat_count = 0
        new_centroids = np.empty(shape=(len(centroids), 2))
        new_cluster_centers = []
        for i in range(len(centroids)):
            clustered_data = Input_File[Input_File["label"] == i]
            sum_x_coordinates = clustered_data["x"].sum()
            sum_y_coordinates = clustered_data["y"].sum()
            den = len(clustered_data)
            new_x_coordinate = sum_x_coordinates / clustered_data.shape[0]
            new_y_coordinate = sum_y_coordinates / clustered_data.shape[0]
            new_centroids[i] = np.array([new_x_coordinate, new_y_coordinate])
            euc_dist = Calc_Distance(coordinates=new_centroids[i], centroids=centroids[i] )
            if (euc_dist == 0):
                repeat_count += 1
            if (repeat_count == 3):
                print("Convergence Reached")
                flag = True
                break
        for i in range (len(new_centroids)):
            new_cluster_centers.append(new_centroids[i])
            centroids[i] = new_cluster_centers[i]
    return None


print(kmeans())
